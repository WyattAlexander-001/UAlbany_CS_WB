import java.util.Scanner; 

public class LabProgram {

   /* Define your method here */

   public static void main(String[] args) {
      /* Type your code here. */
   }
}
