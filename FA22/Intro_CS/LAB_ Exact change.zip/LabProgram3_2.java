import java.util.Scanner; 

public class LabProgram3_2 {
   public static void main(String[] args) {
      /* Type your code here. */
   }
}
