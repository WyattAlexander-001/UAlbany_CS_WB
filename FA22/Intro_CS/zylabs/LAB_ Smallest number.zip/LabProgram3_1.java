import java.util.Scanner;

public class LabProgram3_1 {
   public static void main(String[] args) {
      /* Type your code here. */
   }
}
