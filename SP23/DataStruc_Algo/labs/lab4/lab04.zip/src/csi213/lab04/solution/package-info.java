/**
 * Provides classes for Lab 4.
 */
package csi213.lab04.solution;