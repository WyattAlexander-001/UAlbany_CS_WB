/**
 * Provides classes for Lab 2.
 */
package csi213.lab02;