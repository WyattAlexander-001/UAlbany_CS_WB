/**
 * Provides classes for Lab 1.
 */
package csi213.lab01;